#include <stdio.h>
#include <stdlib.h>

int main()
{
   int onceki_borc,hesap_num,kredi_limiti,musteri_sayisi,i,yeni;
   printf("Lutfen musteri sayisini giriniz.\n");
   scanf("%d",&musteri_sayisi);

   for(i=1;i<=musteri_sayisi;i++)
   {
        printf("Lutfen musteri bilgilerini giriniz.\n");
        printf("%d. musterini hesap numarasi:",i);
        scanf("%d",&hesap_num);
        printf("%d. musterini kredi limiti:",i);
        scanf("%d",&kredi_limiti);
        printf("%d. musterini onceki borcu:",i);
        scanf("%d",&onceki_borc);

        yeni=kredi_limiti/2;
        printf("Yeni duzenlemelerle birlikte %d.musterinin kredi limiti:",i);
        printf("%d\n",yeni);
        if(onceki_borc>yeni)
        {
            printf("%d.Musterinin simdiki balansi yeni kredi limitini asiyor!!\n",i);
        }
    }
}
