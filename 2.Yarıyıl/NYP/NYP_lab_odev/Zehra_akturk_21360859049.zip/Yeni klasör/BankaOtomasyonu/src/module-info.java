/**
 * 
 */
/**
 * @author zehra
 *
 */
module BankaOtomasyonu {
	requires java.desktop;
}