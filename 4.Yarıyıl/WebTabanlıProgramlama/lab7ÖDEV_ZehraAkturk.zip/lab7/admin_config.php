<?php

$admins = [
    'btuadmini' => 'sifre123',
    'bilmuh' => 'bm1071',
    'zehra'=>'kemerli15',
];

?>