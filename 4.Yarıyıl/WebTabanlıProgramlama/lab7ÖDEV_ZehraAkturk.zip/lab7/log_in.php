<!DOCTYPE html>
<html>
<head>
    <title>Login Form</title>
</head>
<body>
    <h2>Login</h2>
    <form action="process_login.php" method="post">
        <label for="username">Kullanıcı Adı:</label>
        <input type="text" id="username" name="username"><br><br>
        <label for="password">Şifre:</label>
        <input type="password" id="password" name="password"><br><br>
        <input type="submit" value="Giriş Yap">
    </form>
</body>
</html>
